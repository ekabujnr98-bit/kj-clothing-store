# KJ Brand Store - Starter

This is a starter Next.js + TypeScript + Tailwind project scaffold for the KJ clothing brand.

## Features
- Next.js app structure
- Tailwind CSS configured
- Sample Header, Hero, ProductCard components
- Stripe checkout API route example
- Placeholder images and sample products

## Quick start
1. Install dependencies:
   ```
   npm install
   ```
2. Add environment variables (see .env.example)
3. Run dev server:
   ```
   npm run dev
   ```

## Files included
- package.json
- tailwind.config.js
- next.config.js
- src/pages/*
- src/components/*
- src/styles/globals.css
- .env.example

Replace placeholder images in /public with your logo and product images.
