Place your logo files (master + minimal variations) and hero/sample images here.
Recommended names: logo-master-classic.png, logo-master-luxury.png, sample-hoodie.jpg, sample-tee.jpg
